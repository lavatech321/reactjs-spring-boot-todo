import '../../index.css';
import Task from './Task';
import UpperOperations from './UpperOperations';


function Operations() {
  return (
    <>
    <UpperOperations></UpperOperations>
    <Task></Task>
    </>
  );
}

export default Operations;